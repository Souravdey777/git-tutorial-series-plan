# Understanding Git 1

What is Git?

Why you should know about it?

how to install Git?

Check if Git is installed or not?