# Understanding Version Control System (VCS)

What is a VCS?

Some popular example of VCS?